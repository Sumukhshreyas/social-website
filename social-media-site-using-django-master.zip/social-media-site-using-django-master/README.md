<h1>social-media-site-using-django</h1></br>
<h2>A fully-functional Social media site named socio made using django framework with its inbuilt mysql database.</h2>
</br>

New project can be created as:</br>
django-admin startproject django_project</br>

New app in project can be created as:</br>
python manage.py startapp socio</br>

start current project by : </br>
> Entering into the django_project directory </br>
> open command prompt here </br>
> type command : python manage.py runerver

<h3>url's</h3></br>
http://127.0.0.1:8000/ - home for navigation </br>
http://127.0.0.1:8000/Newsfeed/ - all post/neewsfeed </br>
http://127.0.0.1:8000/filtered/ - for searching a post </br>
http://127.0.0.1:8000/dashboard/ - user dashboard </br>
http://127.0.0.1:8000/profile/ - user profile -> can see and update his profile </br>
http://127.0.0.1:8000/password-reset/ - to change password </br>
http://127.0.0.1:8000/deactivate/ - to delete account </br>
http://127.0.0.1:8000/post/new/ - for posting new content </br>
http://127.0.0.1:8000/trending/ - most liked pictures </br>
http://127.0.0.1:8000/bookmark/ - saved images by a user </br>
http://127.0.0.1:8000/admin - for admin login and options (default mamanged by django itself.) </br>
